<?php

return [
    'app_info' => [
        'api_id' => '23786918',
        'api_hash' => '650390f594fa668fdcaef705c23a6e44',
    ],
    'logger' => [
        'logger' => 0,
    ],
    'print_update' => true,
];

